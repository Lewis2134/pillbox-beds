## Pillbox Beds

![enter image description here](https://drive.google.com/uc?id=19_RiiaVIQ1hCVDXW2bh-xyG9xBAkPZNz)

This script allows you to lie down on the bed.

Disable animation: F1

## Installation
1. Add the `pillbox-beds` folder to your FiveM resources directory;
2. Edit your server.cfg and add `pillbox-beds`;